import { defineConfig } from "vitest/config";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [tsconfigPaths()],
  test: {
    environment: "node",
    include: ["src/**/*.test.ts", "src/**/*.test.tsx"],
    exclude: ["src/lib/client/kb-storage.test.ts"],
    pool: "threads",
    clearMocks: true,
    sequence: {
      concurrent: false
    }
  }
});
